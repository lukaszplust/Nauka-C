#include <stdio.h>
#include <stdlib.h>
#include "priority_queue_list.h"
void qlist(pqueue* head, void (*print_data)(void*)) {
	pqueue* p;

	for (p = head; p != NULL; p = p->next) {
		printf("%d: ", p->k);
		print_data(p->data);
		printf("\n");
	}

}

void qinsert(pqueue** phead, void* data, int k) {
	//jesli pusta
	if (*phead == NULL) {
		*phead = (pqueue*)malloc(sizeof(pqueue));

		(*phead)->k = k;
		(*phead)->data = data;

		(*phead)->prev = NULL;
		(*phead)->next = NULL;
	}
	//aktualny elem nie jest pusty
	else {
		if ((*phead)->k < k) {//wstawiany elem ma wyzszy priorytet
			if ((*phead)->prev == NULL) {//aktualny elem jest pierwszy w kolejce, nikt nie stoi przed nim
				pqueue* temp = (pqueue*)malloc(sizeof(pqueue));

				temp->data = data;
				temp->k = k;

				temp->prev = NULL;
				temp->next = *phead;

				(*phead)->prev = temp;
				*phead = (*phead)->prev;
			}
			else { // wstawiam miedzy 2 elementy
				pqueue* temp = (pqueue*)malloc(sizeof(pqueue));
				pqueue* prevElem = (*phead)->prev;
				pqueue* nextElem = *phead;
				temp->data = data;
				temp->k = k;

				temp->next = nextElem;
				temp->prev = prevElem;
				prevElem->next = temp;
				nextElem->prev = temp;
			}
		}
		else {//nizszy lub rowny priorytet
			if ((*phead)->next == NULL) {
				pqueue* temp = (pqueue*)malloc(sizeof(pqueue));

				temp->data = data;
				temp->k = k;

				temp->prev = *phead;
				temp->next = NULL;

				(*phead)->next = temp;
			}
			else {
				qinsert(&(*phead)->next, data, k);
			}
		}
	}
}

void qremove(pqueue** phead, int k) {
	if (*phead == NULL) {
		return;
	}
	else if ((*phead)->k == k) {
		//jezeli jest jedynym elementem
		if ((*phead)->next == NULL && (*phead)->prev == NULL) {
			*phead = NULL;
			free((*phead));
			return;
		}
		//jezeli jest pierwszym elementem
		else if ((*phead)->prev == NULL) {
			*phead = (*phead)->next;
			free((*phead)->prev);
			(*phead)->prev = NULL;
			qremove(&(*phead), k);
		}
		//jezeli jest ostatnim elementem
		else if ((*phead)->next == NULL) {
			(*phead)->prev->next = NULL;
			free((*phead));
			return;
		}
		//usuwam ze srodka
		else {
			pqueue* nextElem = (*phead)->next;
			pqueue* prevElem = (*phead)->prev;
			*phead = (*phead)->next;
			free((*phead)->prev);
			nextElem->prev = prevElem;
			prevElem->next = nextElem;
			qremove(&(*phead), k);
		}
	}
	else {
		qremove(&(*phead)->next, k);
	}
}

